package br.upf.usuarios_produtos.dtos

data class LoginDTO(val login: String, val password: String)