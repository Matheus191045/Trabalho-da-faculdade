CREATE TABLE `produto` (
 `id` bigint NOT NULL PRIMARY KEY AUTO_INCREMENT,
 `nome_prod` varchar(255) NOT NULL,
 `preco` int NOT NULL,
 `qtd_estoque` int NOT NULL,
 `descricao` varchar(255) DEFAULT NULL,
 `status` enum('Novo','SemiNovo','Usado','Defeito') DEFAULT NULL
);