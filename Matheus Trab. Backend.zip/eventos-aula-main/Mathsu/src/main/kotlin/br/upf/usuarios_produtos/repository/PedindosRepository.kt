package br.upf.usuarios_produtos.repository

import br.upf.usuarios_produtos.model.Pedindos
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface PedindosRepository: JpaRepository<Pedindos, Long> {
}