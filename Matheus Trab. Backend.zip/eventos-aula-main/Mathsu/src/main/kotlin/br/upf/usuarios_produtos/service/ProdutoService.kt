package br.upf.usuarios_produtos.service

import br.upf.usuarios_produtos.converters.ProdutoConverter
import br.upf.usuarios_produtos.dtos.ProdutoDTO
import br.upf.usuarios_produtos.dtos.ProdutoResponseDTO
import br.upf.usuarios_produtos.exceptions.NotFoundException
import br.upf.usuarios_produtos.repository.ProdutoRepository
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service

private const val PRODUTO_NOT_FOUND_MESSAGE = "Evento não encontrado!"

@Service
class ProdutoService(
    private val repository: ProdutoRepository,
    private val converter: ProdutoConverter
) {

    fun listar(
        nomeProduto: String?,
        paginacao: Pageable): Page<ProdutoResponseDTO> {
        val produtos = if (nomeProduto == null) {
            repository.findAll(paginacao)
        } else {
            repository.findByNome(nomeProduto, paginacao)
        }
        return produtos
            .map(converter::toProdutoResponseDTO)
    }

    fun buscarPorId(id: Long): ProdutoResponseDTO {
        val produto = repository.findById(id)
            .orElseThrow { NotFoundException(PRODUTO_NOT_FOUND_MESSAGE) }
        return converter.toProdutoResponseDTO(produto)
    }

    fun cadastrar(dto: ProdutoDTO): ProdutoResponseDTO {
        return converter.toProdutoResponseDTO(
            repository.save(converter.toProduto(dto))
        )
    }

    fun atualizar(id: Long, dto: ProdutoDTO): ProdutoResponseDTO {
        val produto = repository.findById(id)
            .orElseThrow { NotFoundException(PRODUTO_NOT_FOUND_MESSAGE) }
            .copy(
                nome = dto.nome,
                preco = dto.preco,
                qtdEstoque = dto.qtdEstoque,
                descricao = dto.descricao,
                status = dto.status
            )
        return converter.toProdutoResponseDTO(repository.save(produto))
    }

    fun deletar(id: Long) {
        repository.deleteById(id)
    }
}


