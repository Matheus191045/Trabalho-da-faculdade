package br.upf.usuarios_produtos.dtos

import br.upf.usuarios_produtos.model.StatusProduto
import jakarta.validation.constraints.NotBlank
import jakarta.validation.constraints.NotNull


data class ProdutoDTO(
    @field:NotBlank(message = "Produto sempre deve ter um nome")
    val nome: String,
    @field:NotNull(message = "Produto sempre deve ter um preço")
    val preco: Int,
    @field:NotNull(message = "Produto precisa saber quanto tem estoque")
    val qtdEstoque: Int,
    val descricao: String,
    val status: StatusProduto
)

