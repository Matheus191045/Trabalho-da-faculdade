package br.upf.usuarios_produtos.dtos

import br.upf.usuarios_produtos.model.Pedindos
import br.upf.usuarios_produtos.model.Produto
import br.upf.usuarios_produtos.model.StatusProduto
import java.time.LocalDate
import java.time.LocalDateTime

data class ProdutoResponseDTO (
    val id: Long?,
    val nome: String,
    val preco: Int,
    val qtdEstoque: Int,
    val descricao: String,
    val status: StatusProduto,
    val pedindo: List<Pedindos>
)
