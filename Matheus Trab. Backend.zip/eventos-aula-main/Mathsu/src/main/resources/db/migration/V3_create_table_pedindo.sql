CREATE TABLE `pedindos` (
  `id` bigint NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `usuario_id` bigint NOT NULL,
  `produto_id` bigint NOT NULL,
  `qtd` int NOT NULL,
  `data` datetime NOT NULL,
  FOREIGN KEY (`produto_id`) REFERENCES `produto` (`id`),
  FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`)
);