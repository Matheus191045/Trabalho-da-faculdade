package br.upf.usuarios_produtos.model

enum class StatusProduto {
    Novo,
    SemiNovo,
    Usado,
    Defeito

}

