package br.upf.usuarios_produtos.model

enum class UserRole {
    ADMIN, USER
}